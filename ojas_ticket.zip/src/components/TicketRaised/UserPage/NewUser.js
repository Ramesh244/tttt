import React from 'react'

function NewUser() {
  return (
    <div>
      <h1>Iam New User</h1>
    </div>
  )
}

export default NewUser
